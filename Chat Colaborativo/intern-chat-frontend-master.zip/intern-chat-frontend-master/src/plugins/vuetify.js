import { createVuetify } from 'vuetify'
import '@/assets/scss/main.scss'

const vuetify = createVuetify()

export default vuetify
