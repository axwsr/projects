//src/views/conversations/ConversationsView.vue
<template>
  <div class="flex justify-center items-center h-screen">
    <h1 class="text-4xl font-bold">Messages</h1>
  </div>
</template>
