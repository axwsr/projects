<template>
  <SidebarLeft />
  <SideBarRight />
  <MainContent />
</template>

<script setup>
import MainContent from '@components/layout/MainContent.vue'
import SidebarLeft from '@components/layout/SideBarLeft.vue'
import SideBarRight from '@components/layout/SideBarRight.vue'
</script>
